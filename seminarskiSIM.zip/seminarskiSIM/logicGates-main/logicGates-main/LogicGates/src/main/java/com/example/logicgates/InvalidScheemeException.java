package com.example.logicgates;

public class InvalidScheemeException extends RuntimeException{

    public InvalidScheemeException(String msg) {
        super(msg);
    }
    public InvalidScheemeException(String msg, Gate gate) {
        super(msg);
    }
}
