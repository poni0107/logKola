package com.example.logicgates;

import java.util.function.Consumer;

public class ActionController {

    private static Consumer<Element> action;

    private ActionController(){}

    public static void setAction(Consumer<Element> action) {
        ActionController.action = action;
    }

    public static void performAction(Element element){
        try {
            action.accept(element);
        }
        catch (NullPointerException e){
            System.out.println("Action not found");
        }
    }

    public static boolean hasAction() {
        return action != null;
    }
}
