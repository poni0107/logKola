package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Line;

public class NotGate extends MultiOutputGate  {
    private double width = 40;
    private double height = 20;

    Connection inCon;

    public NotGate(double x, double y, Pane parentPane) {
        super(x, y, parentPane);
        draw();
    }

    protected void redrawConnections() {
        super.redrawConnections();
        if (inCon!=null){
            inCon.ix = getLayoutX() - 3;
            inCon.iy = getLayoutY() + height / 2;
            inCon.erase();
            inCon.draw();
        }
    }

    public void draw() {
        Line leftLine = new Line(0, 0, 0, height);
        leftLine.setStroke(Color.BLACK);

        Line topLine = new Line(0,0,width-6,height/2);
        topLine.setStroke(Color.BLACK);

        Line bottomLine = new Line(0,height,width-6,height/2);
        bottomLine.setStroke(Color.BLACK);

        Arc arc = new Arc(width-3,height/2,3,3,0,360);
        arc.setStroke(Color.BLACK);
        arc.setFill(Color.TRANSPARENT);

        Line input = new Line(-3, height / 2, 0, height / 2);
        input.setStroke(Color.BLACK);
        input.setStrokeWidth(3);

        input.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("in line clicked");
            ActionController.setAction(elem->{
                if (elem==this){
                    return;
                }
                if (inCon!=null){
                    inCon.remove();
                }
                inCon = new Connection(null,this,parentPane);
                inCon.ix = getLayoutX()-3;
                inCon.iy = getLayoutY()+height/2;
                elem.connectWithOut(inCon);
            });
            mouseEvent.consume();
        });

        Line output = new Line(width, height / 2,  width + 3, height / 2);
        output.setStroke(Color.BLACK);
        output.setStrokeWidth(3);

        output.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("out line clicked");
            ActionController.setAction(elem-> {
                if (elem==this){
                    return;
                }
                Connection outCon = new Connection(this,null,parentPane);
                outCons.add(outCon);
                outCon.ox = getLayoutX()+width+3;
                outCon.oy = getLayoutY()+height/2;
                elem.connectWithIn(outCon);
            });
            mouseEvent.consume();
        });

        getChildren().addAll(leftLine, topLine, bottomLine, arc, input, output);
    }

    @Override
    public void connectWithIn(Connection con) {
        if (this == con.outputConGate){
            return;
        }
        if (inCon !=null){
            inCon.remove();
        }
        inCon =con;
        con.ix =getLayoutX()-3;
        con.iy =getLayoutY()+height/2;
        con.inConGate=this;
        con.draw();
        ActionController.setAction(null);
    }

    @Override
    public void connectWithOut(Connection con) {
        outCons.add(con);
        con.ox =getLayoutX()+width+3;
        con.oy =getLayoutY()+height/2;
        con.outputConGate=this;
        con.draw();
        ActionController.setAction(null);
    }

    protected void setEventHandlers() {
        super.setEventHandlers();

        this.setOnMouseClicked(event -> {
            if (event.getButton()==MouseButton.PRIMARY){
                ActionController.performAction(this);
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("AND Gate right-clicked. Removing gate.");
                remove();
            }
        });
    }

    private void setSize() {
        setPrefWidth(width);
        setPrefHeight(height);
    }

    public void remove() {
        if (inCon!=null){
            inCon.remove();
        }
        super.remove();
    }

    @Override
    public boolean calcOut() {
        if (inCon==null){
            throw new InvalidScheemeException("Nothing connected to input line of NOT gate", this);
        }
        return !inCon.outputConGate.calcOut();
    }

    @Override
    public void removeInCon(Connection con) {
        inCon = null;
    }
}
