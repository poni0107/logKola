package com.example.logicgates;



public interface Gate extends Element{
    boolean calcOut();
    void removeOutCon(Connection con);
    void removeInCon(Connection con);
}
