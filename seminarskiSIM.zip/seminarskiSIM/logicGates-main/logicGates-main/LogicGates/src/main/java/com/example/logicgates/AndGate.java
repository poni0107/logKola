package com.example.logicgates;

import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Line;
import javafx.scene.input.MouseButton;

public class AndGate extends MultiInputGate {
    private final double width = 50;
    private final double height = 40;


    public AndGate(double x, double y, Pane parentPane) {
        super(x,y,parentPane);
        draw();
    }

    public void draw() {
        Line leftLine = new Line(0, 0, 0, height);
        leftLine.setStroke(Color.BLACK);

        Arc arc = new Arc();
        arc.setCenterX(0);
        arc.setCenterY(height / 2);
        arc.setRadiusX(width);
        arc.setRadiusY(height / 2);
        arc.setStartAngle(-90);
        arc.setLength(180);
        arc.setType(ArcType.OPEN);
        arc.setStroke(Color.BLACK);
        arc.setFill(Color.TRANSPARENT);

        redrawConnections();
        redrawInputs();

        Line output = new Line(width, height / 2,  width + 3, height / 2);
        output.setStroke(Color.BLACK);
        output.setStrokeWidth(3);

        output.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("out line clicked");
            ActionController.setAction(elem-> {
                if (elem == this){
                    return;
                }
                Connection outCon = new Connection(this,null,parentPane);
                outCons.add(outCon);
                outCon.ox = getLayoutX() + width + 2;
                outCon.oy = getLayoutY() + height/2;
                elem.connectWithIn(outCon);

            });
            mouseEvent.consume();
        });

        getChildren().addAll(leftLine, arc, output);
    }

    @Override
    public void connectWithOut(Connection con) {
        outCons.add(con);
        con.ox = getLayoutX() + width + 3;
        con.oy = getLayoutY() + height/2;
        con.outputConGate = this;
        con.draw();
        ActionController.setAction(null);
    }

    @Override
    protected void setEventHandlers() {
        super.setEventHandlers();

        this.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY){
                ActionController.performAction(this);
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("AND Gate right-clicked. Removing gate.");
                remove();
            }
        });
    }


    @Override
    public boolean calcOut() {
        if (inputCons.isEmpty()){
            throw new InvalidScheemeException("Nothing connected to input line of AND gate",this);
        }
        boolean rez = true;
        for (Connection inputCon : inputCons) {
            if (!inputCon.outputConGate.calcOut()) {
                rez = false;
            }
        }
        return rez;
    }
}
