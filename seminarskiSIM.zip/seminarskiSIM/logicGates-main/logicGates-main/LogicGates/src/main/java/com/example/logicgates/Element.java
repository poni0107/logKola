package com.example.logicgates;

public interface Element {
    void remove();
    void draw();
    void connectWithIn(Connection con);
    void connectWithOut(Connection con);
}
