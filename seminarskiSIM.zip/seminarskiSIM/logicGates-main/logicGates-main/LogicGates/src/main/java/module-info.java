module com.example.logicgates {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.logicgates to javafx.fxml;
    exports com.example.logicgates;
}