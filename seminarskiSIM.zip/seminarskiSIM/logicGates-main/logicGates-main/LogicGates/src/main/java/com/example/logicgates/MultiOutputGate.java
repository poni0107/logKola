package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;

import java.util.ArrayList;
import java.util.List;

public abstract class MultiOutputGate extends Region implements Gate{
    protected double width = 16;
    protected double height = 16;
    protected final Pane parentPane;
    protected double mouseAnchorX;
    protected double mouseAnchorY;

    protected List<Connection> outCons = new ArrayList<>();

    protected MultiOutputGate(double x, double y, Pane parentPane) {
        this.parentPane = parentPane;
        setLayoutX(x);
        setLayoutY(y);
        setEventHandlers();
    }

    protected void setEventHandlers() {
        this.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                mouseAnchorX = event.getX();
                mouseAnchorY = event.getY();
            }
        });

        this.setOnMouseDragged(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                double deltaX = event.getX() - mouseAnchorX;
                double deltaY = event.getY() - mouseAnchorY;
                setLayoutX(getLayoutX() + deltaX);
                setLayoutY(getLayoutY() + deltaY);
                redrawConnections();
            }
        });
    }
    protected void redrawConnections() {
        redrawOutConnections();
    }

    protected void redrawOutConnections() {
        int size = outCons.size();
        for(int i = 0; i < size; i++){
            outCons.get(i).ox=getLayoutX() + this.getWidth() + 3;
            outCons.get(i).oy=getLayoutY() + this.getHeight() / 2;
            outCons.get(i).erase();
            outCons.get(i).draw();
        }
    }

    @Override
    public void connectWithOut(Connection con) {
        outCons.add(con);
        con.ox =getLayoutX()+width+3;
        con.oy =getLayoutY()+height/2;
        con.outputConGate=this;
        con.draw();
        ActionController.setAction(null);
    }
    public void remove() {
        parentPane.getChildren().remove(this);
        removeOutCons();
    }

    private void removeOutCons() {
        while (!outCons.isEmpty()) {
            outCons.get(0).remove();
        }
    }
    public void removeOutCon(Connection con) {
        outCons.remove(con);
    }

}
