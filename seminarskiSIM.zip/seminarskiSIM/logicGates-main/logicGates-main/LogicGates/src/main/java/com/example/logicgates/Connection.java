package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class Connection implements Element {

    double ox, oy, ix, iy;

    Gate outputConGate;
    Gate inConGate;
    Line line;
    private Pane parentPane;


    public Connection(Gate outputConGate, Gate inConGate, Pane parentPane) {
        this.parentPane=parentPane;
        this.outputConGate = outputConGate;
        this.inConGate = inConGate;
    }



    public void draw(){
        if(inConGate==null && outputConGate!=null){
            outputConGate.removeOutCon(this);
            return;
        }
        if(inConGate!=null && outputConGate==null){
            inConGate.removeOutCon(this);
            return;
        }//todo ovo mozda ne treba

        line = new Line(ox, oy, ix, iy);
        line.setStroke(Color.BLACK);
        line.setStrokeWidth(2);
        line.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                ActionController.performAction(this);
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("AND Gate right-clicked. Removing gate.");
                erase();
                remove();
            }
        });
        parentPane.getChildren().add(line);
    }

    @Override
    public void connectWithIn(Connection con) {

    }

    @Override
    public void connectWithOut(Connection con) {

    }

    void erase(){
        parentPane.getChildren().remove(this.line);
    }
    public void remove(){
        outputConGate.removeOutCon(this);
        inConGate.removeInCon(this);
        erase();
    }


}
