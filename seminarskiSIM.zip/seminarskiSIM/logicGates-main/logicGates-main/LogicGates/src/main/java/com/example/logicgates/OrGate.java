package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Line;

import java.util.ArrayList;
import java.util.List;

public class OrGate extends MultiInputGate {
    private double width = 50;
    private double height = 40;

    List<Line> lines=new ArrayList<>();

    public OrGate(double x, double y, Pane parentPane) {
        super(x, y, parentPane);
        draw();
    }

    public void draw() {
        Line leftLine = new Line(0, 0, 0, height);
        leftLine.setStroke(Color.BLACK);

        Arc leftArc = new Arc();
        leftArc.setCenterX(0);
        leftArc.setCenterY(height / 2);
        leftArc.setRadiusX(width / 4);
        leftArc.setRadiusY(height / 2);
        leftArc.setStartAngle(-90);
        leftArc.setLength(180);
        leftArc.setType(ArcType.OPEN);
        leftArc.setStroke(Color.BLACK);
        leftArc.setFill(Color.TRANSPARENT);

        Arc rightArc = new Arc();
        rightArc.setCenterX(0);
        rightArc.setCenterY(height / 2);
        rightArc.setRadiusX(width);
        rightArc.setRadiusY(height / 2);
        rightArc.setStartAngle(-90);
        rightArc.setLength(180);
        rightArc.setType(ArcType.OPEN);
        rightArc.setStroke(Color.BLACK);
        rightArc.setFill(Color.TRANSPARENT);

        redrawConnections();
        redrawInputs();

        Line output = new Line(width, height / 2,  width + 3, height / 2);
        output.setStroke(Color.BLACK);
        output.setStrokeWidth(3);

        output.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("out line clicked");
            ActionController.setAction(elem-> {
                if (elem==this){
                    return;
                }
                Connection outCon = new Connection(this,null,parentPane);
                outCons.add(outCon);
                outCon.ox = getLayoutX()+width+2;
                outCon.oy = getLayoutY()+height/2;
                elem.connectWithIn(outCon);
            });
            mouseEvent.consume();
        });

        getChildren().addAll( leftArc, rightArc, output);
    }

    @Override
    public void connectWithOut(Connection con) {
        outCons.add(con);
        con.ox =getLayoutX()  +width + 3;
        con.oy =getLayoutY() + height / 2;
        con.outputConGate = this;
        con.draw();
        ActionController.setAction(null);
    }

    @Override
    protected void setEventHandlers() {
        super.setEventHandlers();

        this.setOnMouseClicked(event -> {
            if (event.getButton()==MouseButton.PRIMARY){
                ActionController.performAction(this);
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("OR Gate right-clicked. Removing gate.");
                remove();
            }
        });
    }

    @Override
    public boolean calcOut() {
        if (inputCons.isEmpty()){
            throw new InvalidScheemeException("Nothing connected to input line of OR gate",this);
        }
        boolean rez = false;
        for (Connection inputCon : inputCons) {
            if (inputCon.outputConGate.calcOut()) {
               rez = true;
            }
        }
        return rez;
    }
}
