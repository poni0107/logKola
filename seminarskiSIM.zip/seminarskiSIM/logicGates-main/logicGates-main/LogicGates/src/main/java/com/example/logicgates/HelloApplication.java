package com.example.logicgates;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;


public class HelloApplication extends Application {
    List<Output> outputs=new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        
        MenuBar menuBar = new MenuBar();

        Menu newMenu = new Menu("New");

        MenuItem addAndGate = new MenuItem("AND Gate");
        MenuItem addOrGate = new MenuItem("OR Gate");
        MenuItem addNotGate = new MenuItem("NOT Gate");
        MenuItem addInput = new MenuItem("Input");
        MenuItem addOutput = new MenuItem("Output");

        addAndGate.setOnAction(event -> {
            AndGate newAndGate = new AndGate(50, 50, pane);
            pane.getChildren().add(newAndGate);
        });

        addOrGate.setOnAction(event -> {
            OrGate newOrGate = new OrGate(50, 50, pane);
            pane.getChildren().add(newOrGate);
        });

        addNotGate.setOnAction(event -> {
            NotGate newNotGate = new NotGate(50, 50, pane);
            pane.getChildren().add(newNotGate);
        });
        addInput.setOnAction(event -> {
            Input newInput = new Input(50,50,pane);
            pane.getChildren().add(newInput);
        });
        addOutput.setOnAction(event -> {
            Output newOutput = new Output(50,50,pane);
            outputs.add(newOutput);
            pane.getChildren().add(newOutput);
        });

        newMenu.getItems().addAll(addAndGate, addOrGate, addNotGate,addInput,addOutput);
        newMenu.setOnShowing(event -> {
            ActionController.setAction(null);
            menuBar.requestFocus();
        });

        menuBar.getMenus().add(newMenu);

        BorderPane borderPane = createBorderPane(menuBar, pane);

        Scene scene = new Scene(borderPane, 800, 600);
        primaryStage.setTitle("Logic gates");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private BorderPane createBorderPane(MenuBar menuBar, Pane pane) {
        Button moveButton = new Button("Move");
        moveButton.setOnMouseClicked(mouseEvent -> ActionController.setAction(null));

        Button removeButton = new Button("Remove");
        removeButton.setOnMouseClicked(mouseEvent -> ActionController.setAction(Element::remove));

        Button runButton = new Button("Run");
        runButton.setOnMouseClicked(mouseEvent -> {
            try {
                ActionController.setAction(null);
                for (Output out : outputs) {
                    out.calcOut();
                }
            }catch (InvalidScheemeException e){
                System.out.println(e.getMessage());
            }
        });

        HBox topBar = new HBox(menuBar, moveButton, removeButton, runButton);
        topBar.setSpacing(10);

        BorderPane borderPane = new BorderPane();
        borderPane.setTop(topBar);
        borderPane.setCenter(pane);
        return borderPane;
    }

    public static void main(String[] args) {
        launch();
    }
}