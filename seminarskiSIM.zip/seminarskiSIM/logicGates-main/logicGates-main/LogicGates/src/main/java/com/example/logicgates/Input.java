package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.util.ArrayList;

public class Input extends MultiOutputGate {
    private double width = 16;
    private double height = 16;

    private Boolean state = false;
    ArrayList<Line> lines = new ArrayList<>();

    public Input(double x, double y, Pane parentPane) {
        super(x, y, parentPane);
        draw();
    }

    @Override
    protected void setEventHandlers() {
        super.setEventHandlers();

        this.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                if(!ActionController.hasAction()) {
                    state = !state;
                    lines.forEach(line -> line.setStroke(state ? Color.GREEN : Color.BLACK));
                    System.out.println(state);
                }
                else{
                    ActionController.performAction(this);
                }
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("AND Gate right-clicked. Removing gate.");
                remove();
            }
        });
    }

    public void draw(){
        Line leftLine = new Line(0, 0, 0, height);
        leftLine.setStroke(Color.BLACK);

        Line topLine = new Line(0, 0, width, 0);
        topLine.setStroke(Color.BLACK);

        Line rightLine = new Line(width, 0, width, height);
        rightLine.setStroke(Color.BLACK);

        Line bottomLine = new Line(0, height, width, height);
        bottomLine.setStroke(Color.BLACK);

        lines.add(leftLine);
        lines.add(rightLine);
        lines.add(topLine);
        lines.add(bottomLine);

        Line output = new Line(width, height / 2,  width + 3, height / 2);
        output.setStroke(Color.BLACK);
        output.setStrokeWidth(3);

        output.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("out line clicked");
            ActionController.setAction(elem-> {
                if (elem==this){
                    return;
                }
                Connection outCon = new Connection(this,null,parentPane);
                outCons.add(outCon);
                outCon.ox = getLayoutX() + width + 2;
                outCon.oy = getLayoutY() + height / 2;
                elem.connectWithIn(outCon);
            });
            mouseEvent.consume();
        });

        getChildren().addAll(leftLine, rightLine, topLine, bottomLine, output);
    }

    @Override
    public void connectWithIn(Connection con) {
        System.out.println("Does not have Input");
    }

    @Override
    public boolean calcOut() {
        return state;
    }

    @Override
    public void removeInCon(Connection con) {}
}
