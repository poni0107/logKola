package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Line;

public class Output extends Region implements Gate {
    private double width = 16;
    private double height = 16;
    private final Pane parentPane; // Reference to the parent Pane
    private double mouseAnchorX;
    private double mouseAnchorY;
    Arc arc;

    Connection inCon;

    public Output(double x, double y, Pane parentPane) {
        this.parentPane = parentPane;
        setLayoutX(x);
        setLayoutY(y);
        draw();
        setEventHandlers();
    }

    private void setEventHandlers() {
        this.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                mouseAnchorX = event.getX();
                mouseAnchorY = event.getY();
            }
        });

        this.setOnMouseDragged(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                double deltaX = event.getX() - mouseAnchorX;
                double deltaY = event.getY() - mouseAnchorY;
                setLayoutX(getLayoutX() + deltaX);
                setLayoutY(getLayoutY() + deltaY);
                redrawConnections();
            }
        });

        this.setOnMouseClicked(event -> {
            if (event.getButton()==MouseButton.PRIMARY){
                ActionController.performAction(this);
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                System.out.println("AND Gate right-clicked. Removing gate.");
                remove();
            }
        });
    }

    private void redrawConnections() {
        if (inCon != null) {
            inCon.ix = getLayoutX() - 2;
            inCon.iy = getLayoutY() + height / 2;
            inCon.erase();
            inCon.draw();
        }
    }

    public void draw(){
        arc=new Arc(width/2,height/2,width/2,height/2,0,360);
        arc.setStroke(Color.BLACK);
        arc.setFill(Color.TRANSPARENT);

        Line input = new Line(-3, height / 2,  0, height / 2);
        input.setStroke(Color.BLACK);
        input.setStrokeWidth(3);

        input.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("in line clicked");
            ActionController.setAction(elem-> {
                if (elem==this){
                    return;
                }
                if (inCon!=null){
                    inCon.remove();
                }
                inCon = new Connection(null,this,parentPane);
                inCon.ix = getLayoutX()-3;
                inCon.iy = getLayoutY()+height/2;
                elem.connectWithOut(inCon);
            });
            mouseEvent.consume();
        });
        getChildren().addAll(arc, input);
    }

    @Override
    public void connectWithIn(Connection con) {
        if (inCon !=null){
            inCon.remove();
        }
        inCon =con;
        con.ix =getLayoutX()-2;
        con.iy =getLayoutY()+height/2;
        con.inConGate=this;
        con.draw();
        ActionController.setAction(null);
    }

    @Override
    public void connectWithOut(Connection con) {
        System.out.println("Output does not have output pin");
    }

    public void remove() {
        parentPane.getChildren().remove(this);
        if (inCon!=null){
            inCon.remove();
        }
    }





    @Override
    public boolean calcOut() {
        if (inCon == null){
            throw new InvalidScheemeException("Nothing connected to output", this);
        }
        Boolean rez = inCon.outputConGate.calcOut();
        arc.setStroke(rez?Color.GREEN:Color.BLACK);
        return rez;
    }

    @Override
    public void removeOutCon(Connection con) {}

    @Override
    public void removeInCon(Connection con) {
        inCon = null;
    }
}
