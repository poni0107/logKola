package com.example.logicgates;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.util.ArrayList;
import java.util.List;

public abstract class MultiInputGate extends MultiOutputGate {
    private double width = 50;
    private double height = 40;

    protected List<Connection> inputCons = new ArrayList<>();
    List<Line> inputs = new ArrayList<>();
    protected MultiInputGate(double x, double y, Pane parentPane) {
        super(x, y, parentPane);
        setSize();
    }

    @Override
    protected void redrawConnections() {
        redrawOutConnections();
        redrawInputConnections();
    }

    private void redrawInputConnections() {
        int size = inputCons.size();
        double dist = height / (size + 2);
        for(int i = 1; i <= size; i++){
            inputCons.get(i-1).ix=getLayoutX()-3;
            inputCons.get(i-1).iy=getLayoutY() + i * dist;
            inputCons.get(i-1).erase();
            inputCons.get(i-1).draw();
        }
    }
    @Override
    protected void setEventHandlers() {
        this.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                mouseAnchorX = event.getX();
                mouseAnchorY = event.getY();
            }
        });

        this.setOnMouseDragged(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                double deltaX = event.getX() - mouseAnchorX;
                double deltaY = event.getY() - mouseAnchorY;
                setLayoutX(getLayoutX() + deltaX);
                setLayoutY(getLayoutY() + deltaY);
                redrawConnections();
                redrawInputs();
            }
        });
    }
    protected void redrawInputs() {
        inputs.forEach(line -> getChildren().remove(line));

        //for(Line line : lines){
        //    getChildren().remove(line);
        //}
        inputs = new ArrayList<>();
        int size = inputCons.size();
        double dist = height / (size + 2);
        for(int i = 1; i <= size; i++){
            Line line = new Line(-3, i*dist, 0, i*dist);
            line.setStroke(Color.BLACK);
            line.setStrokeWidth(3);
            inputs.add(line);
            getChildren().add(line);
        }

        Line emptyInput = new Line(-3, height - dist, 0, height - dist);
        emptyInput.setStroke(Color.BLACK);
        emptyInput.setStrokeWidth(3);
        inputs.add(emptyInput);
        getChildren().add(emptyInput);

        emptyInput.addEventFilter(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            System.out.println("in line clicked");
            ActionController.setAction(elem-> {
                if (elem==this){
                    return;
                }
                Connection con = new Connection(null,this, parentPane);
                inputCons.add(con);
                con.ix = getLayoutX()-3;
                con.iy = getLayoutY() + height - dist;
                elem.connectWithOut(con);
                redrawConnections();
                redrawInputs();
            });
            mouseEvent.consume();
        });
    }
    public void connectWithIn(Connection con) {
        inputCons.add(con);
        con.inConGate = this;
        redrawConnections();
        redrawInputs();
        ActionController.setAction(null);
    }
    private void setSize() {
        setPrefWidth(width);
        setPrefHeight(height);
    }
    @Override
    public void remove() {
        super.remove();
        removeInCons();
    }

    private void removeInCons() {
        while (!inputCons.isEmpty()) {
            inputCons.get(0).remove();
        }
    }

    public void removeInCon(Connection con) {
        inputCons.remove(con);
        redrawInputs();
        redrawInputConnections();
    }

}
